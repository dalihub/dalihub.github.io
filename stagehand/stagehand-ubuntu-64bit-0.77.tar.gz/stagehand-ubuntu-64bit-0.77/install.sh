#!/bin/bash
dpkg -i ./stagehand-qtdeps_1.02_amd64.deb
dpkg -i ./stagehand_0.77_amd64.deb
apt-get install -f
