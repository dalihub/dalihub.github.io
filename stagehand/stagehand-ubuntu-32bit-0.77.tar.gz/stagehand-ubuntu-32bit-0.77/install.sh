#!/bin/bash
dpkg -i ./stagehand-qtdeps_1.02_i386.deb
dpkg -i ./stagehand_0.77_i386.deb
apt-get install -f
